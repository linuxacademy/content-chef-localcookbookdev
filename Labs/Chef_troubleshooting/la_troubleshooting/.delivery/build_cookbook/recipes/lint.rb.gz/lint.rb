#
# Cookbook:: build_cookbook
# Recipe:: lint
#
# Copyright:: 2019, Student Name, All Rights Reserved.
include_recipe 'delivery-truck::lint'
