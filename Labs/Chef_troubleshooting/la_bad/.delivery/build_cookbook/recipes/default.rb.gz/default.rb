#
# Cookbook:: build_cookbook
# Recipe:: default
#
# Copyright:: 2019, Student Name, All Rights Reserved.
include_recipe 'delivery-truck::default'
