#
# Cookbook:: build_cookbook
# Recipe:: provision
#
# Copyright:: 2019, Student Name, All Rights Reserved.
include_recipe 'delivery-truck::provision'
