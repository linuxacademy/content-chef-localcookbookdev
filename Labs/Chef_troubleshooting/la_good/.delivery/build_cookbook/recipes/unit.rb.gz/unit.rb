#
# Cookbook:: build_cookbook
# Recipe:: unit
#
# Copyright:: 2019, Student Name, All Rights Reserved.
include_recipe 'delivery-truck::unit'
