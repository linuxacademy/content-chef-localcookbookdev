#
# Cookbook:: build_cookbook
# Recipe:: smoke
#
# Copyright:: 2019, Student Name, All Rights Reserved.
include_recipe 'delivery-truck::smoke'
