# la_good
Created by our generator cookbook
TODO: Enter the cookbook description here.

